#Blueskymetrics Spark Framework
## Examples for Spark 2.0 release.

### Build

    sbt clean package